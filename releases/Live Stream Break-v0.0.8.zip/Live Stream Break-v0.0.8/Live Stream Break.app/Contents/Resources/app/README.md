# Live Stream Break
An Electron app for displaying information to your live stream viewers

## How it works

## Features

### Update content on the fly

### Grab data from a spreadsheet

### Timers, to keep you on time

### On-brand

## Download
Grab the latest version here.

## Open source
You can simply clone this repo, run npm install and build features!
